# D-Flat

D-Flat Text User Interface Library

This software licensed under CC0 1.0 Universal License.

This software published as public domain originally.

## History

Al Stevens, released first version of D-Flat in 1991.

Al Stevens released D-Flat 2.0 in 1995.

Alexey Frunze applied some changes to D-Flat in 2017 and 2018.

Ercan Ersoy updates D-Flat since 2020.

## Thanks

Thanks to Al Stevens to author of D-Flat Library.

Thanks to Alexey Frunze to some contributions.
