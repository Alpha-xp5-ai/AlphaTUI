#ifndef DFLAT_H
#define DFLAT_H

// Aggregate public headers
#include <dflat/window.h>
#include "menu.h"
// Add other headers as needed

#endif // DFLAT_H
